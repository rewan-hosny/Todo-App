export class EditTodo {
  id: number = 0;
  title: string = '';
  dueDate: string = '';
  isComplete: boolean = false;
    description: string = '';
  editMode: boolean = false;
  showDescription: boolean = false;
    
}