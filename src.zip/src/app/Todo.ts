export class Todo {
  id: number = 0;
  title: string = '';
  dueDate: string = '';
  isComplete: boolean = false;
  description: string = '';
}