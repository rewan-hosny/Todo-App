import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'filterComplete' })
export class FilterCompletePipe implements PipeTransform {
  transform(items: any[], isCompleted: boolean): any[] {
    return items.filter(item => item.completed === isCompleted);
  }
}
