import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { UserService } from '../app/Service/user-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnChanges, OnInit{
  ngOnInit(): void {
    var token = localStorage.getItem('Authorization');
    this.isloggedIn = !!token;
  }
  
  constructor(
   
    private userService: UserService
  ) {}
  isloggedIn: boolean = false;
  ngOnChanges(changes: SimpleChanges): void {
    var token = localStorage.getItem('Authorization');
    this.isloggedIn = !!token;
  }
  title = 'Todo.UI';
    isLoggedIn = false;

   logout() {
    this.userService.logout();
  }

  isAuthenticated(): boolean {
    return this.userService.isAuthenticated();
  }


}
  

